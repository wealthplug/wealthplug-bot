# Wealthplug bot main file placeholder
print('Bot running')